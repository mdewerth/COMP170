import java.util.Scanner;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args)  {
        String run = "";
        String create;
        Scanner keyboard;
        keyboard = new Scanner(System.in);



        System.out.println("Property Manager");
        System.out.println("Type a command to begin...");
        System.out.println("\"END\" to end the program");
        System.out.println("\"CREATE\" to create a new entity");
        System.out.println("\"CHECK\" to check on rent");
        System.out.println("\"PAY\" to mark payment toward rent");
        while(!run.equalsIgnoreCase("end")) {
            run = keyboard.nextLine();
            while (run.equalsIgnoreCase("create"))  {
                System.out.println("Create a new entity: type an entity to begin:");
                System.out.println("\"PORTFOLIO\"");
                System.out.println("\"BUILDING\"");
                System.out.println("\"LEASE\"");
                System.out.println("\"BACK\" to go home");

                create = keyboard.nextLine();
                while(create.equalsIgnoreCase("portfolio"))    {
                    System.out.println("Create new portfolio:");
                    System.out.println("Enter a name");
                    Portfolio portfolio1 = new Portfolio();
                    portfolio1.setPortfolioName(keyboard.nextLine());
                    break;

                }
                while (create.equalsIgnoreCase("building")) {
                    System.out.println("Create new building:");
                    System.out.println("Enter a name");
                    Building building1 = new Building();
                    building1.setBuildingName(keyboard.nextLine());
                    System.out.println("Enter an address");
                    building1.setBuildingAddress(keyboard.nextLine());
                    System.out.println("Enter number of units");
                    building1.setUnitCount(keyboard.nextInt());
                    System.out.println("Add this building to a portfolio");
                    break;

                }
                while (create.equalsIgnoreCase("apartment"))   {
                    System.out.println("Create a new apartment");
                    System.out.println("Enter unit number");
                    Apartment apartment1 = new Apartment();
                    apartment1.setAddress(keyboard.nextLine());
                    System.out.println("Add to a building");
                    break;
                }
                while(create.equalsIgnoreCase("lease"))   {
                    System.out.println("Create new lease:");
                    System.out.println("Enter a name");
                    Lease lease1 = new Lease();
                    lease1.setLeaseName(keyboard.nextLine());
                    System.out.println("Set rent rate:");
                    lease1.setRent(keyboard.nextInt());
                    System.out.println("Enter lease year");
                    break;

                }
                while(create.equalsIgnoreCase("back"))  {
                    break;
                }

                break;


            }
            while(run.equalsIgnoreCase("check"))    {
                System.out.println("Check rent: choose portfolio");

            }
            while(run.equalsIgnoreCase("pay"))  {
                System.out.println("Select a lease to change payment status");
                String payLease = keyboard.nextLine();
                
            }
            System.out.println("Enter a command");
            System.out.println("\"END\" to end the program");
            System.out.println("\"CREATE\" to create a new entity");
            System.out.println("\"CHECK\" to check on rent");
            System.out.println("\"PAY\" to mark payment toward rent");
            run = keyboard.nextLine();


        }
        keyboard.close();



    }
}
